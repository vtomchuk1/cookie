<?php
?>

<li class="menu-label">Кухня</li>
<li>
    <a href="index.php">
        <div class="parent-icon"><i class='bx bx-cookie'></i>
        </div>
        <div class="menu-title">Список рецептів</div>
    </a>
</li>
<li>
    <a href="dinner.php">
        <div class="parent-icon"><i class="lni lni-chef-hat"></i>
        </div>
        <div class="menu-title">Моя вечеря</div>
    </a>
</li>
<li>
    <a href="products.php">
        <div class="parent-icon"><i class="lni lni-shopping-basket"></i>
        </div>
        <div class="menu-title">Список продуктів</div>
    </a>
</li>
